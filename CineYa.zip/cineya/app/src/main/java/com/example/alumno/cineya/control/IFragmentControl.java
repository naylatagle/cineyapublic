package com.example.alumno.cineya.control;

public interface IFragmentControl {

    void showLoading();
    void hideLoading();
    void goBack();

}
