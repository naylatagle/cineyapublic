package com.example.alumno.cineya.adapters.base;

public interface IAdapterClickListener<T> {
    void onClick(T object);
}
