package com.example.alumno.cineya.helpers;

/**
 * Created by Nayla on 29/11/2017.
 */

public interface OnSuccessCallback {
    void execute(Object body);
}
