package com.example.alumno.cineya.dto;

public class PeliculaInfo {

    private String opcionCine;
    private String peliculaCine;

    public void setOpcionCine(String opcionCine) {
        this.opcionCine = opcionCine;
    }

    public String getOpcionCine(){
        return opcionCine;
    }

    public void setPeliculaCine(String peliculaCine) {
        this.peliculaCine = peliculaCine;
    }

    public String getPeliculaCine(){
        return peliculaCine;
    }
}
